<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0"
          name="viewport">
    <meta content="ie=edge" http-equiv="X-UA-Compatible">
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon" sizes="180x180">
    <link href="assets/img/favicon-32x32.png" rel="icon" sizes="32x32" type="image/png">
    <link href="assets/img/favicon-16x16.png" rel="icon" sizes="16x16" type="image/png">
    <link href="assets/css/style.css" rel="stylesheet">
    <title>بمبر ممد💣</title>
</head>
<body>
<form action="sms.php" class="bomber-form" method="POST">
    <?php
    if (isset($_GET['number']) && $_GET['number'] == 0) { ?>
        <div id="error" class="error">!تارگتو اشتباه زدی عیزم😂</div>
    <?php } elseif (isset($_GET['ok']) && $_GET['ok'] == true) { ?>
        <div id="done" class="done">بمباران اس ام اس تموم شدش😂</div>
    <?php } ?>

    <div id="pending" class="pending">درحال ارسال بمباران💣</div>

    <h3>💣بمبر ممد💣</h3>
    <label for="phone">شماره(با صفر)</label>
    <input id="phone" name="phone" placeholder="09123456789" type="text">
    <button onclick="sending();scrollToBottom()" name="submit">🔥آتش🔥</button>
    <a href="https://panel-xfilm.ir/Bom" target="_blank"><img alt="https://panel-xfilm.ir/Bom" class="git"
                                                                 src="assets/img/github.png"></a>
    <label for="logText">لاگ </label>
    <textarea id="logText" rows="7" cols="30" readonly></textarea>

</form>
<script>
    function sending() {
        if (document.getElementById('error') !== null) {
            let error = window.getComputedStyle(document.getElementById('error')).display
            if (error === 'block') {
                document.getElementById('error').style.display = 'none';
            }
        }

        if (document.getElementById('done') !== null) {
            let done = window.getComputedStyle(document.getElementById('done')).display
            if (done === 'block') {
                document.getElementById('done').style.display = 'none'
            }
        }

        document.getElementById("pending").style.display = "block";
    }

    function readLogFile() {
        fetch('log.txt')
            .then(response => response.text())
            .then(data => {
                document.getElementById('logText').value = data;
            });
    }
    const textarea = document.getElementById('logText');
    function scrollToBottom() {
        textarea.scrollTop = textarea.scrollHeight;
    }

    readLogFile();
    setInterval(readLogFile, 1000);

</script>
</body>
</html>